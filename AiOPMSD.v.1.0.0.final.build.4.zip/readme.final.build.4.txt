
	ALL IN ONE PACK ONLINE MOVIE STREAMING DOWNLOAD (AiOPMSD) v1.0.0 FINAL VERSION BUILD 4
	
	yeah, this is FINAL version. its mean, 99% no bug. but we still need your suport. please send bug to email hayinfx@yahoo.com. thanks 
		
	
	Changelog:
	
	Final version build 4 (sunday september 05 2017) :
	
	- fix Meta Open Graph (missing thumbnail on facebook, Google+ share page etc)
	- fix Meta Open Graph (missing description on facebook, Google+ share page etc)
	
	Final version (sunday september 05 2017) :
	
	- Fix error permalink and title on watch page movie description
	- Change static New movie 2017 slider to dinamic or random new movie 2017
	- remove some empty category on main menu
	- add All category page / main menu link
	- add All Country page / main menu link
	- add ADS baner code
	- remove "id" language
	- fix error sql query that contain (-) hypen
	- add new Share button and remove old share button
	- remove video report
	- remove non sense notice
	- etc.. to many minor update there..
	 
	+++++++++++++++++++++++++++++++++++++++++++++++
	
	 
	All in one pack Online Movie Streaming (AiOPMSD) is free MySQL Database, PHP script for online movie streaming website. no programming skill required. just import database, upload script file and change some configuration.

	Feature:

	- Ready for streaming and Download for 2000+ Movie title.
	- No grabing data or anything from external website.
	- Responive design, mobile friendly, clear and simple.
	- Movie Detail, Thumbnail, Rating, Quality, etc.
	- SEO Friendly.
	- Lightweight. small size, small PHP process, less resource.
	- Cinema Mode aka Turn on , off Light.
	- Online TV streaming
	- Movie streaming
	- Movie Download
	- Multi language (Englih and Indonesia).
	- All Movie stored on powerful and reliabe server, Google Drive for better experience Streaming and Download.
	- 100% FREE! (with footer credit link). if you want to remove credit link, please contact me to buy premium version.
	- PHP Caching to save your MySQL and hosting Quote/Bandwith.
	- ETC..		
	
	
	LIVE DEMO:	http://movie.animecity.xyz
	
	DOWNLOAD :	https://aiopmsd.sourceforge.io
	
	System Requirement
	
	- PHP 5+ , 
	- PHP CURL
	- PDO
	- Apache server
	- .htaccess.
	- MySQL Database.
	
	
	****** Installation guide for upgrade from final build 3 to build 4 only *****
	
	1. Download and Unpack "AiOPMSD.v.1.0.0.final.build.4.zip" archive to your your local PC/Smartphone Disk.
	2.	open your FTP client then delete two file "meta.php" and "watch.php" then upload new "meta.php" and "watch.php" from final build 4 script file to your root directory "PUBLIC_HTML"
	
		DONE...	
		
	
	****** Installation guide for new installation only *****
	
	1. Download and Unpack "AiOPMSD.v.1.0.0.final.zip" archive to your your local PC/Smartphone Disk.
	2. open your PhpMyAdmin and create database "moviedb"
	3. find "conf.sample.php", rename to "conf.php" then open "conf.php" with your text editor and change localhost, username and password with your MySQL Database
	
		$dbhost = 'localhost'; 
		$dbuser = 'username'; 
		$dbpass = 'password'; 
		$dbname = 'moviedb';
	
		next, change "siteurls" and "siteurl" with your site address / domain / sub domain
		
		$siteurl = 'http://movie.animecity.xyz';
		
	4.	back to PhpMyAdmin, clik Import, then choose "movie.enc.zip" from your local PC/Smartphone disk.
	5.	uncheck "Enable foreign key checks" then click "GO" button.
	
		wait.. until "Import has been successfully finished, 44 queries executed. (movie.enc.zip)"
		
		Import Database finished.
		
	6.	open your FTP client then upload all script file to your root directory "PUBLIC_HTML"
	
		DONE...	
	
	
	****** Installation guide for upgrade version only *****
	
	1. Download and Unpack "AiOPMSD.v.1.0.0.final.zip" archive to your your local PC/Smartphone Disk.
	2. find "conf.sample.php", rename to "conf.php" then open "conf.php" with your text editor and change localhost, username and password with your MySQL Database
	
		$dbhost = 'localhost'; 
		$dbuser = 'username'; 
		$dbpass = 'password'; 
		$dbname = 'moviedb';
	
		next, change "siteurls" and "siteurl" with your site address / domain / sub domain
		
		$siteurl = 'http://movie.animecity.xyz';
		
	3.	open your FTP client, dellete all your script file from old version then upload all new script file to your root directory "PUBLIC_HTML"
	
		DONE...
		
		
	if you have some problem installing this script feel free to contact me with my email or via my Facebook private message.		
		
	Contact author:

	E-mail:		hayinfx@yahoo.com
	Facebook:	http://fb.com/HayinSynVengeance
	

	* Sorry for my very very bad english grammar. wkwkwkwk XD		
		